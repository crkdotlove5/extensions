Spree.user_class.class_eval do
  has_many :invoice
end
