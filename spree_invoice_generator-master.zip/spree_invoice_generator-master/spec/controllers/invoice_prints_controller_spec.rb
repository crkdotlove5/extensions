require 'spec_helper'

describe InvoicePrintsController do

end
