module Spree
  Image.class_eval do
    translates :alt
  end
end
