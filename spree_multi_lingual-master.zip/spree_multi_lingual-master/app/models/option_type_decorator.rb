module Spree
  OptionType.class_eval do
    translates :presentation
  end
end