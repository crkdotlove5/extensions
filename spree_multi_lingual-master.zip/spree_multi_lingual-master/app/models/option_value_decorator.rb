module Spree
  OptionValue.class_eval do
    translates :presentation
  end
end