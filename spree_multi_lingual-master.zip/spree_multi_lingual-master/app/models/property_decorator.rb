module Spree
  Property.class_eval do
    translates :presentation
  end
end
