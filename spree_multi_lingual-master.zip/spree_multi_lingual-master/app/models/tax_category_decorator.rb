module Spree
  TaxCategory.class_eval do
    translates :name
  end
end
