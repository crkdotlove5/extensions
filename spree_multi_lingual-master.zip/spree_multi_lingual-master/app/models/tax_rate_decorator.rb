module Spree
  TaxRate.class_eval do
    translates :name
  end
end
