require 'spree_core'
require 'spree_promo'
require 'spree_multi_lingual/engine'
require "globalize3"
require "easy_globalize3_accessors"
require "routing-filter"
require 'spree_multi_lingual/translates_with_accessors'